<?php
session_start();

$dbServername = "localhost";
$dbUsername = "u468215724_ozzy";
$dbPassword = "october28";
$dbName = "u468215724_ozzy";

$con = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if (!isset($_SESSION['f_name'])) {
    header("Location: index.php?error=notloggedin");
} 

$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];
$fullUrl = "http://".$host.$uri;

$name = $_SESSION['f_name'];

$sql = "SELECT * FROM oc_shopChoices WHERE name = '$name'";
$result = mysqli_query($con, $sql);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck < 1) {
    header("Location: selectChoice.php?error=notsubmitted");
    exit();
}

?>
<!doctype html>
<html lang = "en">
    <head>
        <title>Freshman Exploratory Journal</title>
        <meta charset = "UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "styles.css">
        <link rel = "stylesheet" type = "text/css" href = "js/jquery-ui-1.12.1.custom/jquery-ui.css">
        <script src = "js/jquery-3.3.1.min.js"></script>
        <script src = "js/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    </head>    
    <body>
        <header>
            <section class = "banner">
                <section>
                    <a href = "index.php"><img src = "images/oc-logo.png" alt = "Old Colony School Logo"/></a>
                    <a href = "index.php"><h1>Freshman Exploratory Journal</h1></a>
                </section>
                <nav>
                    <a href = "includes/logout.inc.php"><p>Logout</p></a>
                </nav>
            </section>
        </header>
        <main>
            <?php
                $host = $_SERVER['HTTP_HOST'];
                $uri = $_SERVER['REQUEST_URI'];
                $fullUrl = "http://".$host.$uri;
                if (strpos($fullUrl, "upload=success") == true) {
                    echo '<section id = "errNS" title = "Success!">
                            <p class = "ui-state-error">Your Story has been uploaded successfully!</p>
                          </section>
                    ';
                }
            ?>
            <section class = "wrapper" id = "wrapper">
                <section>
                    <?php
                        if (isset($_SESSION['f_name'])) {
                            $name = $_SESSION['f_name'];
                            echo "<h2>".$name."'s Journal</h2>";
                        }
                        if (strpos($fullUrl, "error=bot") == true) {
                            echo '<p id = "announcement" style = "color: red;">An Error has occured. Please try again.</p>';
                        } else {
                            echo '<p id = "announcement" style = "color: white;"></p>';
                        }
                    ?>
                </section>
                <section id = "tabs">
                    <ul>
                        <?php
                        $name = $_SESSION['f_name'];
                        $sql = "SELECT * FROM oc_shopChoices WHERE name = '$name'";
                        $result = mysqli_query($con, $sql);
                        if ($result < 1) {
                            echo '
                                <li><a href = "#tabs-1">Cycle 1</a></li>
                                <li><a href = "#tabs-2">2</a></li>
                                <li><a href = "#tabs-3">3</a></li>
                                <li><a href = "#tabs-4">4</a></li>
                                <li><a href = "#tabs-5">5</a></li>
                                <li><a href = "#tabs-6">6</a></li>
                                <li><a href = "#tabs-7">Ending thoughts</a></li>
                                <li><a href = "#tabs-8">Comments</a></li>
                            ';
                        } else {
                            $row = mysqli_fetch_assoc($result);
                            echo '
                                <li><a href = "#tabs-1">'.$row['c1'].'</a></li>
                                <li><a href = "#tabs-2">'.$row['c2'].'</a></li>
                                <li><a href = "#tabs-3">'.$row['c3'].'</a></li>
                                <li><a href = "#tabs-4">'.$row['c4'].'</a></li>
                                <li><a href = "#tabs-5">'.$row['c5'].'</a></li>
                                <li><a href = "#tabs-6">'.$row['c6'].'</a></li>
                                <li><a href = "#tabs-7">Ending thoughts</a></li>
                                <li><a href = "#tabs-8">Comments</a></li>
                            ';
                        }
                        ?>
                    </ul>
                    <section id = "tabs-1">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d1";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file1'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d1'];
                                    echo $post;
                                } else {
                                    $text = $row['file1'];
                                    $sql = "UPDATE oc_posts SET d1 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d1'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d1'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 1</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file1" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-2">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d2";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file2'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d2'];
                                    echo $post;
                                } else {
                                    $text = $row['file2'];
                                    $sql = "UPDATE oc_posts SET d2 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d2'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d2'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 2</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file2" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-3">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d3";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file3'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d3'];
                                    echo $post;
                                } else {
                                    $text = $row['file3'];
                                    $sql = "UPDATE oc_posts SET d3 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d3'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d3'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 3</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file3" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-4">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d4";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file4'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d4'];
                                    echo $post;
                                } else {
                                    $text = $row['file4'];
                                    $sql = "UPDATE oc_posts SET d4 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d4'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d4'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 4</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file4" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-5">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d5";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file5'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d5'];
                                    echo $post;
                                } else {
                                    $text = $row['file5'];
                                    $sql = "UPDATE oc_posts SET d5 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d5'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d5'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 5</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file5" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-6">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d6";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file6'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d6'];
                                    echo $post;
                                } else {
                                    $text = $row['file6'];
                                    $sql = "UPDATE oc_posts SET d6 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d6'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d6'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 6</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file6" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-7">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d7";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file7'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d7'];
                                    echo $post;
                                } else {
                                    $text = $row['file7'];
                                    $sql = "UPDATE oc_posts SET d7 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d7'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d7'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 7</button>
                        </form>
                        <form class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file7" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                    <section id = "tabs-8">
                        <form action = "includes/submitJournal.inc.php" method = "post">
                            <?php
                            $name = "d8";
                            echo '<textarea name = "'.$name.'" rows = "15">';
                            ?><?php
                            if (strpos($fullUrl, "upload=success") == true) {
                                $fName = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_files WHERE name = '$fName'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if ($row['file8'] == "") {
                                    $name = $_SESSION['f_name'];
                                    $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d8'];
                                    echo $post;
                                } else {
                                    $text = $row['file8'];
                                    $sql = "UPDATE oc_posts SET d8 = '$text' WHERE name = '$fName'";
                                    mysqli_query($con, $sql);
                                    
                                    $name = $_SESSION['f_name'];
                                    $sql2 = "SELECT * FROM oc_posts WHERE name = '$name'";
                                    $result = mysqli_query($con, $sql2);
                                    $row = mysqli_fetch_assoc($result);
                                    $post = $row['d8'];
                                    echo $post;
                                }
                            } else {
                                $name = $_SESSION['f_name'];
                                $sql = "SELECT * FROM oc_posts WHERE name = '$name'";
                                $result = mysqli_query($con, $sql);
                                $row = mysqli_fetch_assoc($result);
                                $post = $row['d8'];
                                echo $post;
                            }
                            ?></textarea>
                            <button type = "submit" name = "submit">Save Cycle 8</button>
                        </form>
                        <form  class = "fileUpload" action = "includes/upload.inc.php" method = "post" enctype = "multipart/form-data">
                            <p>Upload your story</p>
                            <input type = "file" name = "file8" id = "file">
                            <button type = "submit" name = "submit">Upload</button>
                        </form> 
                    </section>
                </section>
            </section>
        </main>
        <footer>
        </footer>
        <script>
            $(document).ready(function() {
                $("#tabs").tabs();
                /*      
                    activate: function(event, ui) {
                        var thing = ui.newTab.index();
                        var i;
                       
                        for (i = 0; i < 7; i++) {
                            if (thing == i) {
                                i++;
                                $(ui.newTab)[0].innerHTML = '<a href="#tabs-' + i + '" role="presentation" tabindex="-1" class="ui-tabs-anchor" id="ui-id-' + i + '">Cycle ' + i + '</a>';
                            }
                        }
                    }
                    
                */
            });
            $(":submit").click(function() {
                $("#announcement").css("color", "white");
                $("#announcement").html("Saving Journal...");
            });
            $("document").ready(function() {
                $("#errNS").dialog();
            
                if ($("#errNS").dialog('isOpen') == true) {
                    $("#wrapper").hide();
                }
                
                $("#errNS").on('dialogclose', function(event) {
                   $("#wrapper").show(); 
                });
            });
        </script>
    </body>
</html>
