<?php
session_start();
if (!isset($_SESSION['f_name'])) {
    header("Location: index.php?error=notloggedin");
}

$dbServername = "localhost";
$dbUsername = "u468215724_ozzy";
$dbPassword = "october28";
$dbName = "u468215724_ozzy";

$con = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

$name = $_SESSION['f_name'];

$sql = "SELECT * FROM oc_shopChoices WHERE name = '$name'";
$result = mysqli_query($con, $sql);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
    header("Location: index.php?error=fieldsubmitted");
    exit();
} 

?>
<!doctype html>
<html lang = "en">
    <head>
        <title>Freshman Exploratory Journal</title>
        <meta charset = "UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "styles.css">
        <link rel = "stylesheet" type = "text/css" href = "js/jquery-ui-1.12.1.custom/jquery-ui.css">
        <script src = "js/jquery-3.3.1.min.js"></script>
        <script src = "js/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    </head>    
    <body>
        <header>
            <section class = "banner">
                <section>
                    <a href = "index.php"><img src = "images/oc-logo.png" alt = "Old Colony School Logo"/></a>
                    <a href = "index.php"><h1>Freshman Exploratory Journal</h1></a>
                </section>
                <nav>
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        echo '<a href = "includes/logout.inc.php"><p>Logout</p></a>';
                    } else {
                        echo '<a href = "login.php"><p>Login</p></a>';
                    }
                    ?>
                </nav>
            </section>
        </header>
        <main>
            <section class = "selectPanel" id = "sP">
                <form class = "allSelections" action = "includes/selections.inc.php" method = "post">
                    <div class = "shopSelections">
                        <label for="firstChoice">First Choice</label>
                        <select name="firstChoice" id="firstChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>
                        
                        <label for="secondChoice">Second Choice</label>
                        <select name="secondChoice" id="secondChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>
                        
                        <label for="thirdChoice">Third Choice</label>
                        <select name="thirdChoice" id="thirdChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>
                        
                        <label for="fourthChoice">Fourth Choice</label>
                        <select name="fourthChoice" id="fourthChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>
                        
                        <label for="fifthChoice">Fifth Choice</label>
                        <select name="fifthChoice" id="fifthChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>
                        
                        <label for="sixthChoice">Sixth Choice</label>
                        <select name="sixthChoice" id="sixthChoice">
                          <option disabled selected>Please select one</option>
                          <option>Automotive</option>
                          <option>Culinary</option>
                          <option>Welding</option>
                          <option>Metal Fab</option>
                          <option>Business Tech</option>
                          <option>Computer Science</option>
                          <option>Graphics</option>
                          <option>Machine and Tool</option>
                          <option>CADD</option>
                          <option>Cosmetology</option>
                          <option>Carpentry</option>
                          <option>Electrical</option>
                          <option>Electronics</option>
                        </select>                        
                    </div>
                    <div class = "townSelections">
                        <label for="sendingTown">Sending Town</label>
                        <select name="sendingTown" id="sendingTown">
                          <option disabled selected>Please select your town</option>
                          <option>Cavah</option>
                          <option>Rochester</option>
                          <option>Lakeville</option>
                          <option>Mattapoisett</option>
                          <option>Acushnet</option>
                        </select>
                        <button type = "submit" name = "submit">Done</button>
                    </div>
                </form>   
                <section class = "selectDescription">
                    <h2>Shop Selections</h2>
                    <?php
                        $host = $_SERVER['HTTP_HOST'];
                        $uri = $_SERVER['REQUEST_URI'];
                        $fullUrl = "http://".$host.$uri;
                        if (strpos($fullUrl, "error=notsubmitted") == true) {
                            echo '<section id = "errNS" title = "Warning!">
                                    <p class = "ui-state-error">You have not submitted your shop selections! This is <strong>required</strong> in order to access your journal.</p>
                                  </section>
                            ';
                        }
                        if (strpos($fullUrl, "error=emptyfields") == true) {
                            echo '<section id = "errNS" title = "Empty Fields">
                                    <p class = "ui-state-error">Please be sure to fill out <strong>All of the fields</strong> before proceeding!</p>
                                  </section>
                            ';                            
                        }
                    ?>
                    <p>These choices will be used to determine what shops you will explore during your <strong>9th grade exploratory.</strong>Please go over your selections with a parent or guardian before submission.</p>
                    <?php
                        $name = $_SESSION['f_name'];
                        echo '<p>Logged in as '.$name.'. <a href = "includes/logout.inc.php" style = "font-weight: bold;">Not you?</a></p>';
                    ?>
                </section>
            </section>
        </main>
        <script>
          $(function() {
            $("#firstChoice").selectmenu();
            $("#secondChoice").selectmenu();
            $("#thirdChoice").selectmenu();
            $("#fourthChoice").selectmenu();
            $("#fifthChoice").selectmenu();
            $("#sixthChoice").selectmenu();
            $("#sendingTown").selectmenu();
            $("#errNS").dialog();
            
            if ($("#errNS").dialog('isOpen') == true) {
                $("#sP").hide();
            }
            
            $("#errNS").on('dialogclose', function(event) {
               $("#sP").show(); 
            });
            
          });
        </script>
    </body>
</html>