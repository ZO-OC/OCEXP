<?php
session_start();
if (isset($_SESSION['f_name'])) {
    header("Location: index.php?error=loggedin");
}
?>
<!doctype html>
<html lang = "en">
    <head>
        <title>Freshman Exploratory Journal</title>
        <meta charset = "UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "styles.css">
        <link rel = "stylesheet" type = "text/css" href = "js/jquery-ui-1.12.1.custom/jquery-ui.css">
        <script src = "js/jquery-3.3.1.min.js"></script>
        <script src = "js/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    </head>    
    <body>
        <header>
            <section class = "banner">
                <section>
                    <a href = "index.php"><img src = "images/oc-logo.png" alt = "Old Colony School Logo"/></a>
                    <a href = "index.php"><h1>Freshman Exploratory Journal</h1></a>
                </section>
                <nav>
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        echo '<a href = "includes/logout.inc.php"><p>Logout</p></a>';
                    } else {
                        echo '<p class = "checked">Login</p>';
                    }
                    ?>
                    <a href = "signup.php"><p>Start</p></a>
                </nav>
            </section>
        </header>
        <main>  
            <?php
                // JQuery UI Error handlers
                $host = $_SERVER['HTTP_HOST'];
                $uri = $_SERVER['REQUEST_URI'];
                $fullUrl = "http://".$host.$uri;
                if (strpos($fullUrl, "error=invalidUser") == true) {
                    echo '<section id = "errNS" title = "Error">
                            <p class = "ui-state-error">Invalid Username or Password. Please try again.</p>
                          </section>
                    ';
                }
                if (strpos($fullUrl, "error=invalidPassword") == true) {
                    echo '<section id = "errNS" title = "Error">
                            <p class = "ui-state-error">Invalid Username or Password. Please try again.</p>
                          </section>
                    ';
                }
                if (strpos($fullUrl, "error=emptyfields") == true) {
                    echo '<section id = "errNS" title = "Empty Fields">
                            <p class = "ui-state-error">Please be sure to enter both your <strong>Username</strong> and your <strong>Password</strong></p>
                          </section>
                    ';
                }
            ?>
            <section class = "signupPanel" id = "signupPanel">
                <form action = "includes/login.inc.php" method = "POST">
                    <label for = "FName">First Name</label>
                    <input id = "FName" name = "FName">
                    <label for = "Password">Password</label>
                    <input id = "Password" name = "Password" type = "password">
                    <button type = "submit" name = "submit">Login</button>
                </form>   
                <section class = "signupDescription">
                    <h2>Login</h2>
                    <p>Log in to access your <strong>Journal Entries</strong></p>
                </section>
            </section>
        </main>
        <footer>
            <section class = "footer">
                <p>Old Colony RVTHS &copy; 2019</p>
            </section>
        </footer>
        <script>
            $("#errNS").dialog();
            
            if ($("#errNS").dialog('isOpen') == true) {
                $("#signupPanel").hide();
            }
            
            $("#errNS").on('dialogclose', function(event) {
               $("#signupPanel").show(); 
            });
        </script>
    </body>
</html>