<?php
session_start();
include 'dbh.inc.php';
if (isset($_POST['submit'])) {
    $firstName = $_POST['FName'];
    $password = $_POST['Password'];
    if (empty($firstName) || empty($password)) {
        header("Location: ../login.php?error=emptyfields");
        exit();
    } else {
        $sql = "SELECT * FROM oc_users WHERE fName = '$firstName'";
        $result = mysqli_query($con, $sql);
        $resultCheck = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);
        if ($resultCheck < 1) {
            header("Location: ../login.php?error=invalidUser");
            exit();
        } else {
            $passwordCheck = password_verify($password, $row['pwd']);
            if ($passwordCheck == false) {
                header("Location: ../login.php?error=invalidPassword");
                exit();
            } else if ($passwordCheck == true) {
                $_SESSION['f_name'] = $row['fName'];
                $_SESSION['l_name'] = $row['lName'];
                header("Location: ../index.php?login=success");
                exit();
            }
        }    
    }    
} else {
    header("Location: ../login.php?error=bot");
    exit();
}
?>
