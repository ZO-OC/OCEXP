<?php
session_start();
include 'dbh.inc.php';
if (isset($_POST['submit'])) {
    foreach ($_FILES as $key => $value) 
        $file = $_FILES["{$key}"];
        
        $fileName = $_FILES["{$key}"]['name'];
        $fileTmpName = $_FILES["{$key}"]['tmp_name'];
        $fileSize = $_FILES["{$key}"]['size'];
        $fileError = $_FILES["{$key}"]['error'];
        $fileType = $_FILES["{$key}"]['type'];
        
        $fileExt = explode('.', $fileName);
        // end() gets the last piece of an array, because explode() gives us an array.
        $fileActualExt = strtolower(end($fileExt));
        
        $allowed = array('txt', 'rtf');
        
        // in_array() means, if the string in $fileActualExt is in the array $allowed...
        
        if (in_array($fileActualExt, $allowed)) {
            if ($fileError === 0) {
                // 500000kb = 500mb
                if ($fileSize < 500000) {
                    // generates a new name for the file.
                    $fileNameNew = uniqid('', true).".".$fileActualExt;
                    $fileDestination = '../uploads/'.$fileNameNew;
                    // this needs to know where the temporary location of the file is ($_FILES['tmp_name']) and where the new location of the file will be ($fileDestination)
                    move_uploaded_file($fileTmpName, $fileDestination);
                    
                    $handle = fopen($fileDestination, 'r+');
                    // feof = file end of file. Basically this while loop is saying what do we want to do WHILE were not at the end of the file
                    $fileText = fgets($handle);
                    $name = $_SESSION['f_name'];
                    
                    $sql2 = "DELETE FROM oc_files WHERE name = '$name'";
                    mysqli_query($con, $sql2);
                    
                    $sql = "INSERT INTO oc_files (name, "."{$key}".") VALUES ('$name', '$fileText');";
                    mysqli_query($con, $sql);
                    
                    fclose($handle);
                    header("Location: ../journal.php?upload=success");
                    exit();
                } else {
                    header("Location: ../journal.php?error=filesizelarge");
                    exit();
                }
            } else {
                header("Location: ../journal.php?error=fileuploaderror");
                exit();
            }
        } else {
            header("Location: ../journal.php?error=invfiletype");
            exit();
        }
        
} else {
    header("Location: ../journal.php?error=bot");
    exit();
}

?>