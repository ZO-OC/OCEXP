<?php
    echo 'Hello, World!';
        echo add();
    function add() {
        $a = 10;
        return $a;
    }
?>