<?php
session_start();
include 'dbh.inc.php';
if (isset($_POST['submit'])) {
    $firstName = $_POST['FName'];
    $lastName = $_POST['LName'];
    $dob = $_POST['DOB'];
    $pwd = $_POST['Password'];
    if (empty($firstName) || empty($lastName) || empty($dob) || empty($pwd)) {
        header("Location: ../signup.php?error=emptyfields");
        exit();
    } else {
        $sql = "SELECT * FROM oc_users WHERE fName = '$firstName'";
        $result = mysqli_query($con, $sql);
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck > 0) {
            header("Location: ../signup.php?error=usertaken");
            exit();
        } else {
            $sql = "SELECT * FROM oc_users WHERE lName = '$lastName'";
            $result = mysqli_query($con, $sql);
            $resultCheck = mysqli_num_rows($result);
            if ($resultCheck > 0) {
                header("Location: ../signup.php?error=usertaken");
                exit();            
            } else {
                if (!ctype_alnum($firstName)) {
                    header("Location: ../signup.php?error=invalidChar");
                    exit();
                } else {
                    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO oc_users (fName, lName, dob, pwd) VALUES ('$firstName', '$lastName', '$dob', '$hashedPwd');";
                    mysqli_query($con, $sql);
                    $sql2 = "SELECT * FROM oc_users WHERE fName = '$firstName'";
                    $result2 = mysqli_query($con, $sql2);
                    $row = mysqli_fetch_assoc($result2);
                    $_SESSION['f_name'] = $row['fName'];
                    $_SESSION['l_name'] = $row['lName'];
                    header("Location: ../selectChoice.php?login=success");
                    exit();
                }
            }
        }
    }    
} else {
    header("Location: ../signup.php?error=bot");
    exit();    
}
?>