<?php
session_start();
include 'dbh.inc.php';
if (!isset($_POST['submit'])) {
    header("Location: ../selectChoice.php?error=bot");
    exit();
} else {
    
    $name = $_SESSION['f_name'];
    $lastName = $_SESSION['l_name'];
    
    $firstChoice = $_POST['firstChoice'];
    $secondChoice = $_POST['secondChoice'];
    $thirdChoice = $_POST['thirdChoice'];
    $fourthChoice = $_POST['fourthChoice'];
    $fifthChoice = $_POST['fifthChoice'];
    $sixthChoice = $_POST['sixthChoice'];
    
    $sendingTown = $_POST['sendingTown'];
    
    if (empty($firstChoice) || empty($secondChoice) || empty($thirdChoice) || empty($fourthChoice) || empty($fifthChoice) || empty($sixthChoice) || empty($sendingTown)) {
        
        header("Location: ../selectChoice.php?error=emptyfields");
        exit();
        
        
    } else {
        
        $sql = "INSERT INTO oc_shopChoices (name, c1, c2, c3, c4, c5, c6, sTown, lastName) VALUES ('$name', '$firstChoice', '$secondChoice', '$thirdChoice', '$fourthChoice', '$fifthChoice', '$sixthChoice', '$sendingTown', '$lastName');";
        mysqli_query($con, $sql);
        header("Location: ../index.php?signup=complete");
        exit();
        
    }    
}
?>