<?php
session_start();
include 'dbh.inc.php';
if (isset($_POST['submit'])) {
    $fName = $_SESSION['f_name'];
    $sql = "SELECT * FROM oc_posts WHERE name = '$fName'";
    $result = mysqli_query($con, $sql);
    $resultCheck = mysqli_num_rows($result);
    foreach ($_POST as $key => $value)
        if ($resultCheck < 1) {
            $sql = "INSERT INTO oc_posts (name, dob, "."{$key}".") VALUES ('$fName', '$dob', '$value')";  
            mysqli_query($con, $sql);
            header("Location: ../journal.php");
            exit();
        } else if ($resultCheck >= 1) {
            $sql = "UPDATE oc_posts SET "."{$key}"." = '$value' WHERE name = '$fName'";
            mysqli_query($con, $sql);
            header("Location: ../journal.php");
            exit();
        }
} else {
    header("Location: ../journal.php?error=bot");
    exit();
}
?>