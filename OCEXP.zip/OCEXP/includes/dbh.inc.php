<?php
$dbServername = "localhost";
$dbUsername = "u468215724_ozzy";
$dbPassword = "october28";
$dbName = "u468215724_ozzy";

$con = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);




