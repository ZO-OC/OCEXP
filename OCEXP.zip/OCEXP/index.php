<?php
session_start();
?>
<!doctype html>
<html lang = "en">
    <head>
        <title>Freshman Exploratory Journal</title>
        <meta charset = "UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "styles.css">
    </head>    
    <body>
        <header>
            <section class = "banner">
                <section>
                    <img src = "images/oc-logo.png" alt = "Old Colony School Logo"/>
                    <h1>Freshman Exploratory Journal</h1>
                </section>
                <nav>
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        echo '<a href = "includes/logout.inc.php"><p>Logout</p></a>';
                        echo '<a href = "journal.php"><p>Journal</p></a>';
                    } else {
                        echo '<a href = "login.php"><p>Login</p></a>';
                        echo '<a href = "signup.php"><p>Start</p></a>';
                    }
                    ?>
                </nav>
            </section>
        </header>
        <main>
            <section class = "gallery">
                <img src = "images/school.jpg" alt = "Old Colony R.V.T.H.S School"/>
                <section>
                    <h2>Freshman Exploratory Journal</h2>
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        $firstName = $_SESSION['f_name'];
                        echo '<p>Welcome back, '.$firstName.'!</p>';   
                    }
                    ?>
                    <p>The Freshman exploratory journal is designed to help Freshman explore their interests while they explore the programs we offer. From CADD To Business Tech Students will gain knowledge from multiple trades while logging their thoughts and interests.</p>  
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        echo '<a href = "journal.php"><button>My Journal</button></a>';  
                    } else {
                        echo '<a href = "signup.php"><button>Start</button></a>'; 
                    }
                    ?>
                </section>
            </section>
        </main>
        <footer>
            <section class = "footer">
                <p>Old Colony RVTHS &copy; 2019</p>
            </section>
        </footer>
    </body>
</html>