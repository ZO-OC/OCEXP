$(document).ready(function() {
    $("#date").datepicker();
    $(document).tooltip();
});