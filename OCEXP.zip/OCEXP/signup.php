<?php
session_start();
if (isset($_SESSION['f_name'])) {
    header("Location: index.php?error=loggedin");
}
?>
<!doctype html>
<html lang = "en">
    <head>
        <title>Freshman Exploratory Journal</title>
        <meta charset = "UTF-8">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel = "stylesheet" type = "text/css" href = "styles.css">
        <link rel = "stylesheet" type = "text/css" href = "js/jquery-ui-1.12.1.custom/jquery-ui.css">
        <script src = "js/jquery-3.3.1.min.js"></script>
        <script src = "js/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
    </head>    
    <body>
        <header>
            <section class = "banner">
                <section>
                    <a href = "index.php"><img src = "images/oc-logo.png" alt = "Old Colony School Logo"/></a>
                    <a href = "index.php"><h1>Freshman Exploratory Journal</h1></a>
                </section>
                <nav>
                    <?php
                    if (isset($_SESSION['f_name'])) {
                        echo '<a href = "includes/logout.inc.php"><p>Logout</p></a>';
                    } else {
                        echo '<a href = "login.php"><p>Login</p></a>';
                    }
                    ?>
                    <p class = "checked">Start</p>
                </nav>
            </section>
        </header>
        <main>
            <section class = "signupPanel">
                <form action = "includes/signup.inc.php" method = "POST">
                    <label for = "FName">First Name</label>
                    <input id = "FName" name = "FName" autocomplete = "off">
                    <label for = "LName">Last Name</label>
                    <input id = "LName" name = "LName" autocomplete = "off">
                    <label for = "DOB">DOB</label>
                    <input id = "DOB" name = "DOB" autocomplete = "off">
                    <label for = "Password">Password</label>
                    <input id = "Password" name = "Password" type = "password" autocomplete = "off">
                    <button type = "submit" name = "submit">Next</button>
                </form>   
                <section class = "signupDescription">
                    <h2>Sign up</h2>
                    <p>Sign up to start a Journal. By signing up, you <strong>understand</strong> that you must be attending Old Colony R.V.T.H.S at the <strong>9th grade level.</strong></p>
                </section>
            </section>
        </main>
        <footer>
            <section class = "footer">
                <p>Old Colony RVTHS &copy; 2019</p>
            </section>
        </footer>
        <script>
            $("document").ready(function() {
                $("#DOB").datepicker({
                    dateFormat: 'mm-dd-yy',
                    changeMonth: false,
                    changeYear: true,
                    maxDate: '-2D'
                });
            });
        </script>
    </body>
</html>